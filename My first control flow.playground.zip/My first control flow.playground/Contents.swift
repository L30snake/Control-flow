//Egg Timer
let eggseconds = 010
let eggminutes = 100
let eggsecond = 050
let seconds = 0.5
let lastsecond = 0
var timer = 300

//Egg cooker
var Timetocook = 2.00
if Timetocook  <= 3.00 {
    print("Its not cooked enough consider adding more seconds.")
} else {
    print("Its cooked enough you can now eat it.")
}

//Timer
timer
timer -= Int(eggminutes)
timer -= Int(eggminutes)
timer -= Int(eggsecond)
timer -= Int(eggsecond)
